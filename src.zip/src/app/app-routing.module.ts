import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Barchart1Component} from './barchart1/barchart1.component';
import { Barchart2Component} from './barchart2/barchart2.component';
const routes: Routes = [
  {path: 'bar-chart1' ,  component: Barchart1Component},
  {path: 'bar-chart2' , component: Barchart2Component}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
