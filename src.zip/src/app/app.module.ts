import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ChartsModule } from 'ng2-charts';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Barchart1Component } from './barchart1/barchart1.component';
import { Barchart2Component } from './barchart2/barchart2.component';
import { InfoboxComponent } from './infobox/infobox.component';
import { Table1Component } from './table1/table1.component';

@NgModule({
  declarations: [
    AppComponent,
    Barchart1Component,
    Barchart2Component,
    InfoboxComponent,
    Table1Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ChartsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
